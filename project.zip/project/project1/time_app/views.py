from django.shortcuts import render
from datetime import datetime

# Create your views here.
def check_time(request):
    current_time=datetime.now().time()
    hour=current_time.hour

    if 5 <= hour < 12:
        greet = "Good Morning!"
    elif 12 <= hour < 17:
        greet = "Good Afternoon!"
    elif 17 <= hour < 21:
        greet = "Good Evening!"
    else:
        greet = "Good Night!"
    context={'greet':greet}
    return render(request,'time.html',context)